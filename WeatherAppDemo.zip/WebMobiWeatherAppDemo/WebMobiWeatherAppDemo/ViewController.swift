//
//  ViewController.swift
//  WebMobiWeatherAppDemo
//


import UIKit
let username = "Kamlesh.sahoo"
let password = "webmobi"
class ViewController: UIViewController {

    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func loginButtonAction(_ sender: Any) {
        //Check for the username and password
        if (self.userNameTF.text == username && passwordTF.text == password){
            self.performSegue(withIdentifier: "ToWeather", sender: self)
        }
    }
    
}

